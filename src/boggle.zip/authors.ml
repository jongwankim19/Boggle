let hours_worked = [15; 10]
